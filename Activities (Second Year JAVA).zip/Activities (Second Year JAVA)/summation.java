import java.util.Scanner;
public class summation
{
    
    public static void main (String[]args)
{
    int a,b,c,sigma;
    int total=0,sum=1;
    Scanner scan = new Scanner (System.in);
    
   System.out.println(" Base: ");
   a=scan.nextInt();
   System.out.println(" Starting Number: ");
   b=scan.nextInt();
   System.out.println(" n^:  ");
   c=scan.nextInt();
   
    
   for(int i=b ;i <= a;i++ )
{
        sum=1;
        sigma=i;

    for(int j = 1;j<=c;j++)
    {
        sum =sum*sigma;
    }
    total=total+sum; 
}
     System.out.println ("Total :  "+total);
}
}